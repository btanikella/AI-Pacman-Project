Author: Bharadwaj Tanikella
GTID: 902773364	

I was unable to test the new test cases which were provided. However the autograder has been run to test the default test cases. 

--- Files Edited ---
BinaryCSP.py
